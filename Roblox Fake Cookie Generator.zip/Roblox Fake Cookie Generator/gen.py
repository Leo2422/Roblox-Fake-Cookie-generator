#by leo.242
import random
import string
import requests

def generate_random_text(length):
    characters = string.ascii_letters + string.digits
    random_text = ''.join(random.choice(characters) for _ in range(length))
    return random_text

webhook_url = ""

word = "_|WARNING:-DO-NOT-SHARE-THIS.--Sharing-this-will-allow-someone-to-log-in-as-you-and-to-steal-your-ROBUX-and-items.|_"
text_length = 350 #Custumize how many digits the cookie will have

random_text = generate_random_text(text_length)

data = {
    "embeds": [
        {
            "title": word,
            "description": random_text,
            "color": 0xFF5733 
        }
    ]
}

response = requests.post(webhook_url, json=data)

if response.status_code == 204:
    print("Message sent successfully!")
else:
    print("Failed to send message.")
    print("Response:", response.text)
